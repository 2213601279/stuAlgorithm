package test;

import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 张驰
 * @Date: 2021/09/08/20:22
 * @Description: 三尺秋水尘不染
 */
public class test2 {
    public static void main(String[] args) {
        return;
    }
}
