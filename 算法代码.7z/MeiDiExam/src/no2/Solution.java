//package no2;
//import java.util.*;
//
//
//public class Solution {
//    /**
//     * 代码中的类名、方法名、参数名已经指定，请勿修改，直接返回方法规定的值即可
//     *
//     *
//     * @param n int整型 总人数
//     * @param m int整型 最大报数值
//     * @return int整型
//     */
//    public int playNum (int n, int m) {
//        // write code here
//    int i = 0;
//    int count = 0;
//    int flag = 0;
//    int temp = 0;
//    temp = count = n;
//    int[] arr = new int[n+1];
//        for (int j = 0; j < n; j++) {
//            arr[j] = 1;
//        }
//
//    }
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int n = sc.nextInt();
//        int m = sc.nextInt();
//        System.out.println(new Solution().playNum(n,m));
//    }
//}