package DFSandBFS;

import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 张驰
 * @Date: 2021/09/17/19:40
 * @Description: 三尺秋水尘不染
 */
//最长回文子串
public class theLongest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println();

    }
}
